from regis import *
from telethon import events, Button

@bot.on(events.NewMessage(pattern=r"(?:.regis|/regis|/sayang|/start)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    inline = [
        [Button.inline(" REGIST ","registrasi"),
         Button.inline(" EXTEND ","perpanjang")],
        [Button.inline(" CHECK","cekip"),
         Button.inline(" DELETE ","deleteip")],
        [Button.inline(" CEK ALL MEMBER ","cekallip"),
         Button.inline(" SSH MANAJER ","ssh")],
        [Button.inline(" VMESS MANAJER ","vmess"),
         Button.inline(" VLESS MANAJER ","vless")],
        [Button.inline(" TROJAN MANAJER ","trojan"),
         Button.inline(" CHANGE ALL LIMIT ","change-limit-all")],
        [Button.inline(" CHANGE ALL QOUTA ","change-all-qouta"),
         Button.inline(" POINTING DOMAIN ","domain")],
        [Button.inline(" CHECK VPS INFO ", "info"),
         Button.inline(" OTHER SETTING ", "setting")],
        [Button.url("ORDER🐳", "https://t.me/freetunnelproject"),

    sender = await event.get_sender()
    val = valid(str(sender.id))
    if val == "false":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except:
            await event.reply("Akses Ditolak")
    elif val == "true":
        sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
        vls = subprocess.check_output(vl, shell=True).decode("ascii")
        tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
        trj = subprocess.check_output(tr, shell=True).decode("ascii")
        sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
        namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
        ipvps = f" curl -s ipv4.icanhazip.com"
        ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
        citsy = f" cat /etc/xray/city"
        city = subprocess.check_output(citsy, shell=True).decode("ascii")

        msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🔰 FREE TUNNEL SCRIPT 🔰**
━━━━━━━━━━━━━━━━━━━━━━━ 
Halo Tuan {sender.first_name}
Selamat Datang Di Layanan Script premium

**» OS     :** `{namaos.strip().replace('"','')}`
**» CITY :** `{city.strip()}`
**» DOMAIN :** `{DOMAIN}`
**» IP VPS :** `{ipsaya.strip()}`
**» Total Account Created:** 

**» 🚀SSH OVPN    :** `{ssh.strip()}` __account__
**» 🎭XRAY VMESS  :** `{vms.strip()}` __account__
**» 🗼XRAY VLESS  :** `{vls.strip()}` __account__
**» 🎯XRAY TROJAN :** `{trj.strip()}` __account__

List Harga Script :** 
🔰**1 BULAN 10k**
🔰**2 BULAN 20k**
🔰**3 BULAN 30K**
🔰**LIFE TIME 1IP 55K**

Note:
**- Anda harus memiliki akses Terlebih Dahulu**
**- Hubungi Admin Agar Anda Mempunyai Akses**.
━━━━━━━━━━━━━━━━━━━━━━━ 
**» Order :** @freetunnelproject
**» Total Pelanggan :** `{ssh.strip()}`
"""
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)
